#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>

/*
	>>>> Start your function at here: BF, BF_Path
*/


int main(){
    for (int i = 0; i< 2000; i++){
        int BFValue[20];
        int BFPrev[20];
        int G[20][20];
        string path_out ="" + to_string(i) +".txt";
        string path_in = "" + to_string(i) +".txt";
        ofstream file_out (path_out);
        ifstream file_in(path_in);
        int size; file_in >> size;
        cout << size << endl;
        char src; file_in >> src;
        cout << src << endl;
        for (int r = 0; r < size; r++){
            BFValue[r] = -1;
            BFPrev[r] = -1;
            for (int j = 0; j < size; j++)
                file_in>>G[r][j];
        }
        file_in.close();
        for(int id=0;id<size;id++){
            BF(G,size,src,BFValue,BFPrev);
            file_out<<"step"<<id+1<<":"<<endl;
            for(int j=0;j<size;j++){
                file_out<<BFValue[j]<<" ";
            }
            file_out<<endl;
            for(int j=0;j<size;j++){
                file_out<<BFPrev[j]<<" ";
            }
            file_out<<endl;
        }
        file_out.close();
    }
    for (int i = 0; i < 2000; i++){
    	string path_output = "" + to_string(i) + ".txt";
    	string path_expect = "" + to_string(i) + ".txt";
    	fstream file_out (path_out);
    	fstream file_expect (path_expect);
    	stringstream stream_output;
    	stringstream stream_expect;
    	stream_output << file_out.rdbuf();
    	stream_expect << file_expect.rdbuf();
    	if (stream_expect.str() != stream_output.str()){
    		cout <<"ERROR:  " << i << endl;
    	}
    }
}